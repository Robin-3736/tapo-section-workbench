# Tapo Section Workbench — team distribution

Internal Codex plugin for building and reviewing reusable Tapo Shopify sections in an unpublished draft theme.

## Install for a colleague

1. Get access to this private GitHub repository, then clone it or download and extract the repository ZIP.
2. Open a terminal in the extracted repository root and register the marketplace:

   ```sh
   codex plugin marketplace add "$PWD"
   codex plugin add tapo-section-workbench@tapo-internal
   ```

3. Connect Shopify using your own account with access to the intended store and draft theme. Install the Shopify plugin for its development skills. The interactive brief also uses Codex's Visualize capability and browser tools; these must be available in your Codex environment.
4. Start a new Codex task and say **Open Tapo Section Workbench**.

The package contains the launcher, section workflow, Tapo brand references, and reusable examples. Shopify authentication, chat history, and locally created theme sections are not included. Sections already saved to a Shopify draft remain available through that store's Theme Editor.

## Repository structure

- `.agents/plugins/marketplace.json`: team marketplace registration.
- `plugins/tapo-section-workbench/`: complete installable plugin.

## Updating

Pull the latest repository changes, run `codex plugin add tapo-section-workbench@tapo-internal` again, and start a new task. Keep the local clone in place while using it as a local marketplace.

## Access

Keep this repository private. Repository owners can grant colleagues access in GitHub's repository settings. Each colleague authenticates their own Shopify connection; repository access does not grant store permissions.

## Store and draft selection

The opening form requires a country/market, store handle, and the Theme Editor URL of your explicitly chosen unpublished draft. Use **Help me choose a draft theme** to request a read-only list from your store. No UK store or theme is preselected. Codex verifies the selected store and theme before writing and stops if the theme is live or inaccessible. Existing installations must reinstall this updated package and start a new task.
