# Tapo Section Workbench

An internal Codex plugin for designing, approving, implementing, and verifying reusable Tapo Shopify sections.

## What it does

1. Provides a visual storefront brief; reference images and files must be attached directly in the Codex chat composer.
2. Starts a real Codex coding run from the workbench rather than advancing a checklist.
3. Requires the user to explicitly select a store and unpublished Shopify Draft Theme and checks template limits before coding.
4. Preserves remote Theme Editor changes and implements a uniquely named Online Store 2.0 Liquid section.
5. Applies the established Tapo brand identity and real product data.
6. Verifies remote persistence and responsive behaviour in the real Draft Theme.
7. Opens the exact section-focused Shopify Theme Editor URL for feedback.
8. Uses HTML exploration only when explicitly requested or approved for unresolved complexity.
9. Stops before publication for final approval.

## Safety boundaries

- Never edits or publishes a live theme.
- Never removes or replaces existing template content without explicit approval.
- Treats the latest remote Draft Theme as authoritative.
- Keeps Shopify credentials outside the plugin package.
- Requires each user to authenticate their own Shopify access.

## Team distribution

This plugin is packaged through the repo marketplace at `.agents/plugins/marketplace.json`. Team members with access to the private repository can add that marketplace, install the plugin, connect Shopify, and start a new Codex task.
