---
name: tapo-html-shopify-section
description: Design, implement, iterate, and verify reusable Tapo Shopify Online Store 2.0 sections directly in an unpublished Draft Theme through a Liquid-first workflow. Use when a user asks to create, redesign, or refine a Tapo storefront section, responsive theme component, product or promotion module, FAQ, banner, card, or content block. Start from the Tapo Section Workbench Brief, preserve the latest remote Theme Editor state, apply the established Tapo brand identity, open the exact section in Shopify Theme Editor for feedback, and never publish or modify the live theme without explicit authorization. Use an HTML prototype only when the user explicitly requests exploration or the design has substantial unresolved visual or interaction complexity.
---

# Tapo Liquid-first Shopify Section

Turn a storefront Brief directly into a configurable section in an unpublished Tapo Shopify Draft Theme. Use the real theme, products, images, prices, and Theme Editor as the default design and approval environment.

## Entry points

- When the user supplies a complete Brief, execute the Liquid-first workflow immediately.
- When the user asks to open, launch, or start Tapo Section Workbench without a complete Brief, use `$tapo-section-workbench-launcher` to display the interactive Brief launcher.
- Keep one section project in one Codex conversation so later feedback modifies the same section instance.
- Treat the internal skill name as a compatibility identifier. Do not infer an HTML-first workflow from it.

## Load required context

Read these files completely before acting:

- `references/brand-identity.md` on every invocation, without exception.
- `references/shopify-environment.md`.
- `references/section-quality-checklist.md`.
- `references/approved-qa-baseline.md` for FAQ, accordion, support, or two-column content sections.

Also read `references/product-commerce-pattern.md` when products, prices, discounts, gifts, highlights, variants, or cart actions are involved.

Use `assets/tapo-responsive-qa-approved.liquid` only as an implementation pattern. Never assume its remote instance or settings are current.

## Workbench-triggered runs

When the request contains `WORKBENCH PROJECT` or `SECTION BRIEF`, treat it as an execution request from the Brief launcher.

- Start once all required Brief fields are present.
- Treat uploaded host file IDs and attached files as authoritative references.
- Preserve prior artifacts and remote settings during revisions.
- Do not describe a version as approved unless the user explicitly approved it.
- Return and open the exact section-focused Draft Theme Editor deep link.
- Never imply that the launcher tracks Codex progress or completion.
- Never treat Draft Theme approval as publication authorization.

## Choose the execution mode

Default to **Liquid-first**.

Use optional **HTML exploration** only when:

- the user explicitly asks for an HTML prototype;
- several materially different visual directions need comparison;
- interaction or motion is substantially unresolved;
- the approver cannot access Shopify; or
- implementing the first Liquid version would create disproportionate rework.

If HTML exploration is not explicitly requested, do not add it as a mandatory gate. When it is useful but not required, explain why and obtain the user's agreement before inserting it.

## Liquid-first workflow

### 1. Resolve the Brief and current Shopify state

Extract the goal, content hierarchy, merchant controls, target template, insertion position, responsive behavior, interactions, products, and approved copy.

Inspect every reference file. Separate reusable structure from third-party branding and apply the Tapo brand reference instead.

Before writing:

1. Require an explicit store handle, country/market, and theme ID or Theme Editor URL from the user. Never infer them from ambient browser state or reference files. If missing, list accessible stores/themes read-only and ask the user to choose; do not begin implementation.
2. Verify the authenticated store matches the selected handle and the selected theme ID belongs to that store with an unpublished role. Never choose the latest, first, similarly named, or previously used theme. If missing, inaccessible, or live, stop and request a new explicit choice. Never create or duplicate a theme automatically.
3. Confirm that the target is not the live theme.
4. Pull the latest remote target template and every remote file that may change.
5. Inspect the template's section count, order, disabled sections, and Shopify limits.
6. Detect Theme Editor changes since the last turn.
7. Choose a unique section filename, schema name, and instance ID.
8. Resolve real product handles, variants, images, prices, compare-at prices, and links when commerce content is involved.

Treat theme names, IDs, handles, instance IDs, and URLs as discovery hints only. Fresh remote state is authoritative.

If the target template is at a Shopify limit, stop before overwriting anything and ask which existing instance may be removed or replaced.

### 2. Implement the Online Store 2.0 section

Use the Shopify Liquid and Shopify CLI skills and follow their required documentation-search and validation steps.

Build a self-contained section with:

- merchant-editable content and useful native Shopify pickers;
- repeatable blocks when the content model is repeatable;
- `block.shopify_attributes` on block wrappers;
- CSS and JavaScript scoped to the section instance;
- theme-editor-safe initialization;
- semantic, accessible markup;
- visible keyboard focus and touch targets of at least 44 px;
- reduced-motion handling when motion exists;
- clean behavior when optional settings or blocks are removed;
- no brittle dependency on app-owned DOM or private app logic.

At minimum, expose controls that are useful for the design:

- desktop and mobile top, bottom, and horizontal padding;
- maximum width;
- relevant corner radii;
- section, card, text, accent, border, and button colours;
- content selection, count, labels, and links.

Apply the Tapo brand identity exactly:

- Poppins;
- brand blue `#015EAC`;
- product titles at weight `600`;
- product highlights at weight `500`;
- bright, clean, product-led surfaces;
- generous configurable radii;
- pill badges and strongly rounded buttons;
- large, undistorted product imagery;
- no card shadows by default.

Use real Shopify product data rather than prototype prices or placeholder imagery. Let content determine height.

### 3. Merge and upload safely

Immediately before upload:

1. Re-check authenticated store identity and re-list themes in that store. Confirm the exact explicitly selected theme ID still belongs to that store and remains unpublished. Stop on any mismatch; never substitute a theme.
2. Pull the latest remote versions of all files that will change again.
3. Compare them with the earlier baseline.
4. Merge narrowly and preserve every unrelated section, block, setting, order entry, and user edit.
5. Confirm filename, schema, and instance IDs still do not collide.
6. Validate Liquid, schema, and template JSON.

Add the instance at the exact requested position. Upload only the necessary files to the resolved unpublished theme. Never use live-theme flags and never publish.

### 4. Verify remote persistence and the real Draft Theme

After upload:

1. Pull the changed remote files again.
2. Confirm the remote section matches the intended local file.
3. Confirm the remote template contains the instance at the requested order position.
4. Open the real Draft Theme storefront for verification only.
5. Validate desktop, narrow desktop/editor, 375 px, and another small width.
6. Test interactions rather than inferring them from markup.
7. Check heading visibility, collisions, touch targets, optional states, content order, and image fit.
8. Check horizontal overflow with `document.documentElement.scrollWidth > innerWidth`.
9. Read computed Poppins family, weights, colours, radii, spacing, and visibility.
10. Verify real product data and merchant-edited settings from the remote template.
11. Separate new-section defects from pre-existing theme defects.

Fix failures, validate again, upload only the affected files, and repeat remote verification.

Use `references/section-quality-checklist.md` as the release gate.

### 5. Open the exact Theme Editor section

After the real Draft page passes verification:

1. Read the rendered wrapper ID for the exact instance, such as `shopify-section-template--EXAMPLE__section_instance`.
2. Remove the `shopify-section-` prefix.
3. URL-encode the remaining value as the Theme Editor `section` query parameter.
4. Build `https://admin.shopify.com/store/{store_handle}/themes/{theme_id}/editor?section={section_parameter}`.
5. Open that exact URL in the in-app browser and keep it as the approval tab.

If Shopify requests account verification, leave the verification page open and ask the user to complete it.

Do not give the storefront preview as the approval destination by default. Provide it only when the user explicitly asks or troubleshooting requires it.

### 6. Iterate from Theme Editor feedback

Treat the latest remote Draft Theme as authoritative on every revision.

For each feedback round:

1. Pull the current remote section and template.
2. Preserve user changes made in Theme Editor.
3. Apply the requested revision narrowly.
4. Validate and upload only affected files.
5. Pull back and verify persistence.
6. Re-test affected responsive widths and interactions.
7. Reopen the same section-focused Editor deep link.

Do not reintroduce an HTML approval gate during Liquid revisions.

### 7. Hand off for Shopify approval

Report:

- Draft Theme name and section-focused Theme Editor deep link;
- unique section name and changed remote files;
- target template and insertion position;
- initial content and merchant controls;
- validation and responsive checks;
- known pre-existing or app-owned limitations.

Stop before publication. The user decides whether to request revisions or separately authorize publication.

## Optional HTML exploration

When the user approves HTML exploration:

1. Create a unique, self-contained local prototype.
2. Apply the same Tapo brand identity and real content hierarchy.
3. Validate 1440, 1024, 901, 900, 768, 375, and 320 px where applicable.
4. Open the prototype for review.
5. Require explicit approval before translating it to Liquid.
6. Treat the later real Draft Theme as authoritative for products, images, prices, theme CSS, limits, and final responsive behavior.

HTML exploration never authorizes Draft Theme publication.

## Guardrails

- Brand identity is mandatory and never memory-only.
- Never modify or publish the live theme without explicit authorization.
- Remote Draft Theme state wins over local copies.
- Preserve Theme Editor edits, including edits that differ from earlier defaults.
- Do not use stale theme IDs, templates, product handles, instance IDs, or URLs.
- Do not replace a similar section by display name alone.
- Do not silently remove unrelated sections to satisfy template limits.
- Keep content-driven height and never clip text, prices, gifts, images, or actions.
- Keep each section independently configurable without global regressions.
- Leave Upsell and other app-owned eligibility or cart logic to the app unless a public interface is verified.

## Example invocations

- “Open Tapo Section Workbench and build this section directly in the unpublished Draft Theme.”
- “Use `$tapo-html-shopify-section` to create a homepage promotion and open its exact Theme Editor section.”
- “Refine this Tapo Draft Theme section and preserve my latest Theme Editor changes.”
- “Explore three HTML directions first, then implement the approved one in the Draft Theme.”

## Reference attachment handling

The form does not upload files. Users must attach references directly to the Codex chat. Never treat a filename or an ID written in a brief as proof that a file is available. If the brief says references were attached, inspect actual accessible attachments before implementing; if missing, pause and ask for the attachment. Never silently proceed without required references.
