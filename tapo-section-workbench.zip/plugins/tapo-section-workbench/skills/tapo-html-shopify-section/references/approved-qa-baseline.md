# Approved Tapo Responsive Q&A Baseline

Use this reference for FAQ, accordion, customer-support, or comparable two-column sections. It records a proven pattern, not permanent remote state.

## Approved structure

- Desktop: two columns with the heading/support/button on the left and a label/accordion card on the right.
- Desktop column tops align.
- Tablet and mobile switch to one column at 900 px and below.
- Mobile order: heading, questions, support copy, button.
- Heading wraps to two balanced lines.
- Accordion uses circular down/up chevrons, not plus/minus symbols.
- Only one item remains open.
- No card shadow.
- Touch targets exceed 44 px.

## Latest merchant-edited defaults observed

These values were read from the unpublished Shopify Theme Editor after implementation:

- Maximum width: `1800px`.
- Desktop padding: top `56px`, horizontal `36px`, bottom `80px`.
- Mobile padding: top `44px`, horizontal `10px`, bottom `48px`.
- Section radius: `10px`.
- FAQ card radius: `12px`.
- Section background: `#FFFFFF`.
- FAQ card background: `#F4F4F4`.
- Text: `#111820`.
- Supporting text: `#55616D`.
- Accent and button: `#015EAC`.
- Soft icon surface: `#EAF4FC`.
- Border: `#DFE4E8`.

Do not hard-code these as immutable brand rules. Use them as initial defaults only when they suit the brief, and always re-pull the current remote template before implementation.

## Proven implementation

Inspect `../assets/tapo-responsive-qa-approved.liquid` for:

- section-scoped CSS variables;
- editable padding, radii, colors, maximum width, blocks, and links;
- `details`/`summary` markup;
- section-scoped accordion behavior;
- responsive breakpoint structure;
- focus and reduced-motion handling.

Create a new unique section for new work. Do not overwrite the approved example or its remote instance by default.
