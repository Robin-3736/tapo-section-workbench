# Tapo UK Brand Identity

Apply these defaults unless the user approves a deliberate exception.

## Core visual language

- Primary brand color: `#015EAC`.
- Typography: Poppins for all section UI.
- Product title: Poppins SemiBold, weight `600`.
- Product highlights: Poppins Medium, weight `500`.
- Supporting text: weight `400` or `500` according to hierarchy.
- Style: clean, product-led, bright, approachable, and functional.
- Prefer white and very light neutral surfaces. Use `#F2F3F5` as a practical starting neutral.
- Do not add card shadows by default.
- Use generous rounded corners for cards; start around `20px` and make the value configurable where appropriate.
- Make badges fully pill-shaped with a large radius such as `999px`.
- Use pill or strongly rounded buttons. Primary buttons use the brand blue; secondary buttons use a blue outline or a restrained neutral style.
- Keep product imagery large and immediately legible. Avoid decorative effects that compete with the product.

## Layout behavior

- Use a centered, configurable section container that fits the active theme.
- On wide desktop, product modules may form a two-column list when their content remains readable.
- At narrower widths, reduce columns before text or controls become cramped.
- On mobile, stack media above content unless the approved HTML prototype demonstrates a better pattern.
- Prevent horizontal overflow at 375 px.
- Let content determine card height. Do not clip product highlights, prices, gifts, or buttons with fixed heights.
- Use consistent internal padding and clear vertical rhythm.
- Keep touch targets at least 44 px where practical.

## Content hierarchy

For commerce cards, use this default order when the approved design does not specify another:

1. savings badge over the media;
2. product media;
3. product title;
4. gift preview, if present;
5. up to three highlights;
6. price and compare-at price;
7. two actions.

Use `Save X%` for generated savings badges. Round the percentage to a whole number unless the user requests another format.

## Accessibility

- Maintain readable contrast for text, borders, badges, and buttons.
- Provide useful image alt text from product data or merchant settings.
- Preserve keyboard focus visibility.
- Do not rely on color alone to explain states.
- Respect reduced-motion preferences when adding motion.
