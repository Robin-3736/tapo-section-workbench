# Product Commerce Section Pattern

Read this reference for sections containing Shopify products or promotions.

## Recommended data model

Use section blocks for repeatable product cards. A typical product block supports:

- Shopify product picker;
- custom card image override;
- badge text override;
- gift product or image preview;
- gift label, title override, and value override;
- up to three highlight overrides;
- primary and secondary button labels and URLs;
- optional visual overrides only when section-wide settings are insufficient.

Let the selected product supply title, URL, featured image, price, compare-at price, and first available variant by default.

## Savings percentage

Only calculate a percentage when `compare_at_price > price` and both values are valid.

Conceptually:

`saving = round((compare_at_price - price) * 100 / compare_at_price)`

Render `Save {{ saving }}%`. Allow merchant-entered badge text to override the calculation. Hide the badge when neither a valid saving nor override exists.

## Highlights

Prefer explicit block overrides first. If the theme already stores product highlights in a verified metafield, use that as fallback.

Inspect the actual metafield type and rendered value before choosing a filter. Rich text, list, and HTML-like strings require different handling. Never expose literal markup such as `<ul><li>` to customers.

Render no more than three visible highlights. Strip empty values and preserve accessible list semantics where practical.

## Gift preview

Treat the card's gift display as presentational until the Upsell app's public interface is verified.

Provide configurable:

- gift label;
- gift product or image;
- gift title;
- value text;
- border color and width;
- background color;
- corner radius.

Keep the preview compact and allow long gift names to wrap. Do not make theme JavaScript responsible for app campaign eligibility.

## Actions

Use a real Shopify product form for Add to Cart:

- include a valid variant ID;
- respect product availability;
- preserve any theme-required cart behavior where possible;
- test whether the active cart drawer or page updates correctly.

Use the product URL for Buy Now or Learn More unless a specific target is approved. Do not call a normal product-page link “Buy Now” if the user expects an immediate checkout action.

## Responsive structure

For the established showcase pattern:

- desktop: media and content share the card horizontally;
- narrow layouts: reduce to one card per row before internal content becomes cramped;
- mobile: place media above content;
- keep the badge over the media with safe inset spacing;
- let gift, highlights, price, and actions expand the card naturally;
- avoid fixed heights and card shadows;
- use a full-radius badge and the brand typography rules.
