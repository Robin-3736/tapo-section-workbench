# Section Quality Checklist

Use this as the final Draft Theme release gate. Repeat affected checks after every fix.

## Brief and scope

- [ ] The Brief, target template, insertion position, interactions, and approved copy are understood.
- [ ] Every available reference file was inspected.
- [ ] Liquid-first is being used unless the user approved optional HTML exploration.
- [ ] If HTML exploration was used, that specific prototype version was explicitly approved.
- [ ] The section has a unique filename, schema name, and instance ID.
- [ ] The intended target is an unpublished Draft Theme.
- [ ] No live-theme action is included.

## Remote-state protection

- [ ] Themes were freshly listed and the intended Draft Theme role was confirmed.
- [ ] The latest remote template and every file to be changed were pulled before editing.
- [ ] The template section count and Shopify limits were checked before insertion.
- [ ] The files were pulled again immediately before upload.
- [ ] Theme Editor changes were detected and preserved.
- [ ] No unrelated section, block, setting, order entry, or file was overwritten.
- [ ] Any removal or replacement needed for a Shopify limit was explicitly approved.

## Merchant controls

- [ ] Section width and outer spacing are configurable where useful.
- [ ] Content selection uses native Shopify pickers where possible.
- [ ] Repeatable content uses blocks or an appropriate setting.
- [ ] Custom imagery can override product imagery where useful.
- [ ] Optional content hides without empty gaps.
- [ ] Relevant colours, borders, backgrounds, and radii are configurable.
- [ ] Blocks include `block.shopify_attributes`.

## Brand and responsive design

- [ ] Poppins is the effective font.
- [ ] Product titles compute to weight `600`.
- [ ] Product highlights compute to weight `500`.
- [ ] Brand blue is `#015EAC`.
- [ ] Cards have no shadow unless explicitly approved.
- [ ] Badges are fully rounded.
- [ ] Generated discounts say `Save X%`.
- [ ] The real Draft Theme composition matches the intended hierarchy.
- [ ] The 375 px composition is approved-quality.
- [ ] The section has no horizontal overflow.
- [ ] Pre-existing page overflow is separated from section-specific overflow.
- [ ] Long titles, highlights, gift names, and prices wrap safely.
- [ ] Images fit intentionally without distortion or clipping.
- [ ] Buttons remain usable and touch targets are at least 44 px.
- [ ] Focus and reduced-motion behavior are correct where relevant.

## Commerce and app behavior

- [ ] Correct real products and variants are selected.
- [ ] Product title, URL, featured image, price, and compare-at price are real.
- [ ] Automatic saving percentage handles missing or invalid compare-at prices.
- [ ] Add to cart uses a valid product form and variant ID when included.
- [ ] Secondary actions target the intended URL.
- [ ] Gift preview data is accurate.
- [ ] The Upsell app remains responsible for gift eligibility and fulfilment.
- [ ] App-owned limitations are documented without overstating integration.

## Technical verification

- [ ] Liquid syntax, section schema, and template JSON validate.
- [ ] Shopify template and schema limits pass.
- [ ] CSS and JavaScript are scoped to the section instance.
- [ ] Theme Editor block selection works.
- [ ] Only necessary files were uploaded.
- [ ] Uploaded files were pulled back and match the intended versions.
- [ ] The remote template contains the instance at the exact requested position.
- [ ] The real Draft page renders without new Liquid or JavaScript errors.
- [ ] Desktop, narrow desktop/editor, 375 px, and another small width were checked.
- [ ] Interactions were tested in the real Draft page.
- [ ] Computed styles confirm font, weights, colours, radii, and spacing.
- [ ] Optional settings or blocks can be removed cleanly.

## Editor handoff

- [ ] The rendered wrapper ID for the exact section instance was read from the real Draft page.
- [ ] The wrapper ID was converted into a section-focused Admin Theme Editor URL.
- [ ] The Editor URL opens the exact section instance.
- [ ] The section-focused Theme Editor is opened as the Shopify approval surface.
- [ ] The storefront preview is omitted unless explicitly requested or needed for troubleshooting.
- [ ] Draft Theme name, section name, changed files, position, controls, checks, and limitations are summarized.
- [ ] The theme remains unpublished.
