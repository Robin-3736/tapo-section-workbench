# Tapo Shopify Environment

Use this file to accelerate discovery. Re-check all mutable values before writing.

## Explicit project destination

This plugin has no default store, country, theme ID, theme name, or page.

- Obtain the country/market, Shopify store handle, and selected theme ID or Theme Editor URL from the opening Brief.
- A URL identifies the user's choice; it does not prove the theme is unpublished.
- Authenticate using the colleague's own Shopify connection and verify the selected store and exact theme ID remotely.
- If selection is missing, list accessible unpublished themes read-only and ask for an explicit choice. Never preselect even if only one draft exists.
- If access is missing, ask for the correct connection. Never fall back to another store or theme.
- Preserve the selected store/theme pair throughout revisions. A target change requires a new explicit selection.
- Recheck identity, ownership and unpublished status immediately before every write. Stop if a theme became live or disappeared.
- Use the selected market's language, currency, products and app configuration. Reference assets are patterns, never target identifiers.

## Safe theme workflow

1. Confirm the admin store context.
2. List or inspect themes and resolve the intended unpublished theme by current name and role.
3. Read the latest remote template JSON and relevant section/snippet files.
4. Create a uniquely named section rather than replacing a similar existing one.
5. Validate locally or with Shopify tooling.
6. Push only the necessary files to the unpublished theme.
7. Open the actual Draft Theme preview and verify the intended page.
8. Leave publication to the user unless they explicitly request it.

If the local export and remote theme differ, treat the remote Draft Theme as authoritative for files being changed. Merge narrowly and preserve unrelated sections, blocks, settings, and ordering.

## Upsell and gift behavior

The validated store uses a Shopify app referred to as Upsell, with Koala-related app embeds observed during implementation. App campaign rules may be private and unavailable to theme Liquid.

- Do not infer gift eligibility from a visual preview.
- Do not duplicate the app's campaign or cart logic in theme JavaScript.
- Render a merchant-configurable gift preview when the design calls for it.
- Use a standard Shopify product form for the main product.
- Verify whether the app recognizes that cart event in the Draft Theme.
- If public metafields, metaobjects, app blocks, or Liquid drops become available, prefer them over duplicated manual data.
- Clearly label any manual gift display as preview-only in implementation notes, while keeping storefront copy customer-friendly.

## Operational safety

- Never publish the theme as part of the normal skill workflow.
- Never modify a live theme without explicit authorization.
- Never replace an existing section based only on a similar display name.
- Avoid broad theme pushes.
- Verify the uploaded remote file and the rendered preview after each meaningful iteration.
