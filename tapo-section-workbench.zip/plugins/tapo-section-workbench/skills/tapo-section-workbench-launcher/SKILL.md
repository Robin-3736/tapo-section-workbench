---
name: tapo-section-workbench-launcher
description: Open and display the interactive Tapo Section Workbench Brief launcher inside Codex. Use when the user says "Open Tapo Section Workbench", asks to start the Tapo workbench, wants the Brief form, or wants a guided UI before beginning a Liquid-first Tapo Shopify Draft Theme section project.
---

# Tapo Section Workbench Launcher

Show the interactive Brief launcher. Do not start designing or coding until the user submits it.

## Launch

1. Read and follow the available `visualize` skill completely.
2. Copy `assets/tapo-brief-launcher.html` unchanged into the current thread-scoped visualization directory as `tapo-section-workbench.html`.
3. Read the copied file back and confirm it is a literal HTML fragment.
4. Present it with the exact inline visualization directive required by the `visualize` skill.

Do not replace the launcher with a written questionnaire, external website, Runner, checklist, or explanation.

## After submission

The launcher sends a structured Liquid-first request to `$tapo-section-workbench:tapo-html-shopify-section` in the current Codex task.

- Treat the submitted Brief as the project source of truth.
- Let the execution skill create and validate the real Liquid section in the explicitly selected unpublished Shopify Draft Theme.
- Keep revisions in the same conversation.
- Open the exact section-focused Shopify Theme Editor URL for feedback.
- Use HTML exploration only when the user explicitly requests it or agrees that unresolved complexity justifies it.
- Never modify or publish the live theme without explicit authorization.
- Never imply that the launcher tracks Codex progress or completion.

## Reference attachment handling

The form does not upload files. Users must attach references directly to the Codex chat. Never treat a filename or an ID written in a brief as proof that a file is available. If the brief says references were attached, inspect actual accessible attachments before implementing; if missing, pause and ask for the attachment. Never silently proceed without required references.
